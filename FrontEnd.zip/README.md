# React Admin Dashboard

Build a COMPLETE React Admin Dashboard App | React, Material UI, Data Grid, Light & Dark Mode

Video: https://www.youtube.com/watch?v=wYpCWwD1oz0

For all related questions and discussions about this project, check out the discord: https://discord.gg/2FfPeEk2mX
<select data-mdb-select-init multiple>
  <option value="1">One</option>
  <option value="2">Two</option>
  <option value="3">Three</option>
  <option value="4">Four</option>
  <option value="5">Five</option>
  <option value="6">Six</option>
  <option value="7">Seven</option>
  <option value="8">Eight</option>
</select>