import { Box, useTheme } from "@mui/material";
import Header from "../../components/Header";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { tokens } from "../../theme";
import { useEffect, useState } from "react";
import { Button } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { showAllUser } from "../../context/Slice/loginSlice";
import { createPermissionsByUserId } from "../../context/Slice/permissionSlice";


const initialPermissions = {
  Dashboard: { can_view: false, can_create: false, can_update: false, can_delete: false },
  DoctorList: { can_view: false, can_create: false, can_update: false, can_delete: false },
  UserList: { can_view: false,can_create: false, can_update: false, can_delete: false },
  HospitalLists: { can_view: false,can_create: false, can_update: false, can_delete: false },
  ManageTeam: { can_view: false },
  ModulePermissions:{ can_view: false },
  ProfileForm: { can_view: false },
  BarChart: { can_view: false },
  Calendar: { can_view: false },
  GeographyChart: { can_view: false },
  LineChart: { can_view: false },
  PieChart: { can_view: false },
  FAQ: { can_view: false },

};


const ModulePermissions = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const dispatch = useDispatch();
  const allUsers = useSelector((state) => state.loginR.user);

  useEffect(() => {
    dispatch(showAllUser());
  }, []);

  const [selectedName, setSelectedName] = useState('');
  const [permissions, setPermissions] = useState(initialPermissions);

 
  const handleNameChange = (event) => {
    const name = event.target.value;
    setSelectedName(name);
  };


  const handleCheckboxChange = (section, permission) => (event) => {
    setPermissions(prevPermissions => ({
      ...prevPermissions,
      [section]: {
        ...prevPermissions[section],
        [permission]: event.target.checked,
      }
    }));
  };

  
  const handleSubmit = () => {
    const selectedUser = allUsers.find(user => user.firstName === selectedName);
    if (selectedUser) {
    
      const result = {
        userId: selectedUser.id,
        permissionsArray: {
          role: selectedUser.role,
          permissions: permissions, 
        },
      };
  
   
      dispatch(createPermissionsByUserId(result));
      console.log(result);  
    } else {
      console.error('User not found');
    }
  };
  

  return (
    <Box m="20px">
      <Header title="Permission  Modules" />

      <div className="row mb-4">
        <div className="col-md-6">
          <div className="form-group">
            <label htmlFor="name-select">Select Name:</label>
            <select
              id="name-select"
              className="form-select"
              value={selectedName}
              onChange={handleNameChange}
            >
              <option value="">--Select a Name--</option>
              {allUsers.map(user => (
                <option key={user.id} value={user.firstName}>
                  {user.firstName} {user.lastName}    {`role :${user.role}`}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

     
      {Object.keys(permissions).map(section => (
        <Accordion defaultExpanded key={section}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography color={colors.greenAccent[500]} variant="h5">
              {section}
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px',marginBottom:'30px' }}>
              {Object.keys(permissions[section]).map(permission => (
                <div key={permission}>
                  <input
                    type="checkbox"
                    id={`${section}-${permission}`}
                    checked={permissions[section][permission]}
                    onChange={handleCheckboxChange(section, permission)}
                  />
                  <label htmlFor={`${section}-${permission}`}>
                    {permission.replace('_', ' ').toUpperCase()}
                  </label>
                </div>
              ))}
            </div>
          </AccordionDetails>
        </Accordion>
      ))}

      <Button type="button" className="btn btn-primary mt-5" onClick={handleSubmit}>
        Submit
      </Button>
    </Box>
  );
};

export default ModulePermissions;
