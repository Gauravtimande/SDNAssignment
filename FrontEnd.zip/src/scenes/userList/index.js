import React, { useEffect, useState } from "react";
import { Box, Button, IconButton } from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { tokens } from "../../theme";
import Header from "../../components/Header";
import { useTheme } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { showAllUser, deleteUser } from "../../context/Slice/loginSlice";
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import Swal from 'sweetalert2';
import UserCreateForm from "../../scenes/form/UserCreateForm";
import UserUpdateForm from "../form/UserUpdateForm";
import { usePermissions } from '../../context/PermissionsContext';

const UserList = () => {
  const { userPermissions } = usePermissions();
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const dispatch = useDispatch();
  const allUsers = useSelector((state) => state.loginR.user);

  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    dispatch(showAllUser());
  }, [dispatch]); // Remove allUsers.length dependency if not necessary

  const handleDeleteUser = (id) => {
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',
    }).then((result) => {
      if (result.isConfirmed) {
        dispatch(deleteUser(id)).then(() => {
          Swal.fire('Deleted!', 'The user has been deleted.', 'success');
          dispatch(showAllUser()); // Refresh list after deletion
        }).catch((error) => {
          Swal.fire('Error!', 'There was an error deleting the user.', 'error');
        });
      }
    });
  };

  const handleEditUser = (user) => {
    setSelectedUser(user);
    setIsEditing(true);
  };

  const handleAddUser = () => {
    setIsAdding(true);
  };

  const handleFormClose = () => {
    setIsAdding(false);
    setIsEditing(false);
    setSelectedUser(null);
  };

  const columns = [
    { field: "id", headerName: "ID", flex: 0.5 },
    { field: "firstName", headerName: "First Name", flex: 1 },
    { field: "lastName", headerName: "Last Name", flex: 1 },
    { field: "role", headerName: "Role", flex: 1 },
    { field: "email", headerName: "Email", flex: 1 },
    { field: "mobile_number", headerName: "Phone Number", flex: 1 },
    {
      field: "actions",
      headerName: "Actions",
      flex: 1,
      renderCell: (params) => (
        <Box>
          {userPermissions?.UserList?.can_update && (
            <IconButton onClick={() => handleEditUser(params.row)}>
              <EditIcon style={{ color: colors.greenAccent[200] }} />
            </IconButton>
          )}
          {userPermissions?.UserList?.can_delete && (
            <IconButton onClick={() => handleDeleteUser(params.row.id)}>
              <DeleteIcon style={{ color: colors.redAccent[200] }} />
            </IconButton>
          )}
        </Box>
      ),
    },
  ];

  return (
    <Box m="20px">
      { (!isAdding && !isEditing) && userPermissions?.UserList?.can_view && (
        <>
          <Header title="USERS LIST" />
          <Box display="flex" justifyContent="flex-end" m="20px">
            {userPermissions?.UserList?.can_create && (
              <Button
                variant="contained"
                color="primary"
                startIcon={<AddIcon />}
                onClick={handleAddUser}
              >
                Add User
              </Button>
            )}
          </Box>
          <Box
            m="40px 0 0 0"
            height="75vh"
            sx={{
              "& .MuiDataGrid-root": { border: "none" },
              "& .MuiDataGrid-cell": { borderBottom: "none" },
              "& .MuiDataGrid-columnHeaders": {
                backgroundColor: colors.blueAccent[700],
                borderBottom: "none",
              },
              "& .MuiDataGrid-virtualScroller": {
                backgroundColor: colors.primary[400],
              },
              "& .MuiDataGrid-footerContainer": {
                borderTop: "none",
                backgroundColor: colors.blueAccent[700],
              },
              "& .MuiCheckbox-root": {
                color: `${colors.greenAccent[200]} !important`,
              },
              "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
                color: `${colors.grey[100]} !important`,
              },
            }}
          >
            <DataGrid
              rows={allUsers}
              columns={columns}
              components={{ Toolbar: GridToolbar }}
            />
          </Box>
        </>
      )}
      {userPermissions?.UserList?.can_create && isAdding && <UserCreateForm handleFormClose={handleFormClose} refreshUserList={() => dispatch(showAllUser())} />}
      {userPermissions?.UserList?.can_update && isEditing && <UserUpdateForm handleFormClose={handleFormClose} selectedUser={selectedUser} refreshUserList={() => dispatch(showAllUser())} />}
    </Box>
  );
};

export default UserList;
