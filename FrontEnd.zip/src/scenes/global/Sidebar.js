import React from 'react';
import { usePermissions } from '../../context/PermissionsContext';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Sidebar.css';

// Import Material-UI icons
import HomeOutlinedIcon from '@mui/icons-material/HomeOutlined';
import PeopleIcon from '@mui/icons-material/People';
import MedicalServicesIcon from '@mui/icons-material/MedicalServices';
import HospitalIcon from '@mui/icons-material/Home';
import SettingsIcon from '@mui/icons-material/Settings';
import BarChartIcon from '@mui/icons-material/BarChart';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import MapIcon from '@mui/icons-material/Map';
import ShowChartIcon from '@mui/icons-material/ShowChart';
import PieChartIcon from '@mui/icons-material/PieChart';

const Sidebar = () => {
  const { userPermissions } = usePermissions();

  return (
    <div className="sidebar bg-dark text-light">
      <ul className="nav flex-column">
        {/* Check if permissions are available and can_view is true */}
        {userPermissions?.Dashboard?.can_view && (
          <li className="nav-item">
            <Link to="/dashboard" className="nav-link text-light">
              <HomeOutlinedIcon /> Dashboard
            </Link>
          </li>
        )}
        {userPermissions?.UserList?.can_view && (
          <li className="nav-item">
            <Link to="/userList" className="nav-link text-light">
              <PeopleIcon /> User List
            </Link>
          </li>
        )}
        {userPermissions?.DoctorList?.can_view && (
          <li className="nav-item">
            <Link to="/DoctorList" className="nav-link text-light">
              <MedicalServicesIcon /> Doctor List
            </Link>
          </li>
        )}
        {userPermissions?.HospitalLists?.can_view && (
          <li className="nav-item">
            <Link to="/HospitalLists" className="nav-link text-light">
              <HospitalIcon/>
               Hospital Lists
            </Link>
          </li>
        )}
        {userPermissions?.ModulePermissions?.can_view && (
          <li className="nav-item">
            <Link to="/ModulePermissions" className="nav-link text-light">
              <SettingsIcon /> Module Permissions
            </Link>
          </li>
        )}
        {userPermissions?.BarChart?.can_view && (
          <li className="nav-item">
            <Link to="/bar" className="nav-link text-light">
              <BarChartIcon /> Bar Chart
            </Link>
          </li>
        )}
        {userPermissions?.Calendar?.can_view && (
          <li className="nav-item">
            <Link to="/Calendar" className="nav-link text-light">
              <CalendarTodayIcon /> Calendar
            </Link>
          </li>
        )}
        {userPermissions?.GeographyChart?.can_view && (
          <li className="nav-item">
            <Link to="/geography" className="nav-link text-light">
              <MapIcon /> Geography Chart
            </Link>
          </li>
        )}
        {userPermissions?.LineChart?.can_view && (
          <li className="nav-item">
            <Link to="/line" className="nav-link text-light">
              <ShowChartIcon /> Line Chart
            </Link>
          </li>
        )}
        {userPermissions?.PieChart?.can_view && (
          <li className="nav-item">
            <Link to="/pie" className="nav-link text-light">
              <PieChartIcon /> Pie Chart
            </Link>
          </li>
        )}
      </ul>
    </div>
  );
};

export default Sidebar;
