import React, { useState } from "react";
import { Box, Typography, TextField, Button } from "@mui/material";
import { useDispatch } from "react-redux";
import { createHospital } from "../../context/Slice/hospitalSlice";
import styles from "./HospitalCreateForm.module.css";

export default function CreateHospital({ handleFormClose, refreshHospitalList }) {
  const dispatch = useDispatch();

  const [formState, setFormState] = useState({
    name: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    phone_number: "",
    email: "",
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const postData = { ...formState };
    console.log(postData);

    try {
      await dispatch(createHospital(postData));
      // refreshHospitalList(); // Refresh the list after creation
      handleFormClose(); // Close the form after submission
    } catch (error) {
      console.error("Registration error:", error);
      // Handle error (e.g., show an error message to the user)
    }
  };

  return (
    <div className={styles.container}>
      <Box component="form" className={styles.form} onSubmit={handleSubmit}>
        <Typography component="h1" variant="h5">Create Hospital</Typography>
        {/* Form fields */}
        <TextField margin="normal" required fullWidth name="name" id="name" label="Hospital Name" value={formState.name} onChange={handleChange} />
        <TextField margin="normal" required fullWidth name="address" id="address" label="Address" value={formState.address} onChange={handleChange} />
        <TextField margin="normal" required fullWidth name="city" id="city" label="City" value={formState.city} onChange={handleChange} />
        <TextField margin="normal" required fullWidth name="state" id="state" label="State" value={formState.state} onChange={handleChange} />
        <TextField margin="normal" required fullWidth name="zipCode" id="zipCode" label="Zip Code" value={formState.zipCode} onChange={handleChange} />
        <TextField margin="normal" fullWidth name="phone_number" id="phone_number" label="Phone Number" value={formState.phone_number} onChange={handleChange} />
        <TextField margin="normal" fullWidth name="email" id="email" type="email" label="Email Address" value={formState.email} autoComplete="email" onChange={handleChange} />
        {/* Submit and Close buttons */}
        <Button type="submit" fullWidth variant="contained" sx={{ mt: 3, mb: 2 }}>Submit</Button>
        <Button fullWidth variant="contained" sx={{ mt: 2, mb: 2 }} onClick={handleFormClose}>Close</Button>
      </Box>
    </div>
  );
}
