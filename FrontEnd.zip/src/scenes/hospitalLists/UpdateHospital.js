import React, { useState, useEffect } from "react";
import { Box, Typography, TextField, Button } from "@mui/material";
import { useDispatch } from "react-redux";
import { updateHospital} from "../../context/Slice/hospitalSlice"; // Ensure this action is properly defined for hospital updates
import styles from "./HospitalCreateForm.module.css"; // Adjust the CSS module name as needed

export default function UpdateHospital({ refreshHospitalList, handleFormClose, selectedHospital }) {
  const dispatch = useDispatch();

  const [formState, setFormState] = useState({
    name: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    phone_number: "",
    email: "",
  });

  useEffect(() => {
    if (selectedHospital) {
      setFormState({
        name: selectedHospital.name || "",
        address: selectedHospital.address || "",
        city: selectedHospital.city || "",
        state: selectedHospital.state || "",
        zipCode: selectedHospital.zipCode || "",
        phone_number: selectedHospital.phone_number || "",
        email: selectedHospital.email || "",
      });
    }
  }, [selectedHospital]);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const updatedData = { id: selectedHospital.id, formState };
    console.log(updatedData);

    try {
      await dispatch(updateHospital(updatedData)); 
      refreshHospitalList();
      handleFormClose();
    } catch (error) {
      console.error("Update error:", error);
      // Handle error (e.g., show an error message to the user)
    }
  };

  return (
    <div className={styles.container}>
      <Box component="form" className={styles.form} onSubmit={handleSubmit}>
        <Typography component="h1" variant="h5">Update Hospital</Typography>

        {/* Name Field */}
        <TextField
          margin="normal"
          required
          fullWidth
          name="name"
          id="name"
          label="Hospital Name"
          value={formState.name}
          onChange={handleChange}
        />

        {/* Address Field */}
        <TextField
          margin="normal"
          required
          fullWidth
          name="address"
          id="address"
          label="Address"
          value={formState.address}
          onChange={handleChange}
        />

        {/* City Field */}
        <TextField
          margin="normal"
          required
          fullWidth
          name="city"
          id="city"
          label="City"
          value={formState.city}
          onChange={handleChange}
        />

        {/* State Field */}
        <TextField
          margin="normal"
          required
          fullWidth
          name="state"
          id="state"
          label="State"
          value={formState.state}
          onChange={handleChange}
        />

        {/* Zip Code Field */}
        <TextField
          margin="normal"
          required
          fullWidth
          name="zipCode"
          id="zipCode"
          label="Zip Code"
          value={formState.zipCode}
          onChange={handleChange}
        />

        {/* Phone Number Field */}
        <TextField
          margin="normal"
          fullWidth
          name="phone_number"
          id="phone_number"
          label="Phone Number"
          value={formState.phone_number}
          onChange={handleChange}
        />

        {/* Email Field */}
        <TextField
          margin="normal"
          fullWidth
          name="email"
          id="email"
          type="email"
          label="Email Address"
          value={formState.email}
          autoComplete="email"
          onChange={handleChange}
        />

        {/* Submit Button */}
        <Button type="submit" fullWidth variant="contained" sx={{ mt: 3, mb: 2 }}>
          Submit
        </Button>
        <Button fullWidth variant="contained" sx={{ mt: 2, mb: 2 }} onClick={handleFormClose}>
          Close
        </Button>
      </Box>
    </div>
  );
}
