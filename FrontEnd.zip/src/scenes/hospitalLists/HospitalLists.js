import React, { useEffect, useState } from 'react';
import { Box, Button, IconButton } from '@mui/material';
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { tokens } from '../../theme';
import Header from '../../components/Header';
import { useTheme } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { fetchHospitals, deleteHospital } from '../../context/Slice/hospitalSlice';
import { usePermissions } from '../../context/PermissionsContext';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import Swal from 'sweetalert2';
import CreateHospital from '../hospitalLists/CreateHospital';
import UpdateHospital from '../hospitalLists/UpdateHospital'; // Updated to UpdateHospital

const HospitalLists = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const dispatch = useDispatch();
  const allHospitals = useSelector((state) => state.hospitalR.hospitals);
  const { userPermissions } = usePermissions();

  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedHospital, setSelectedHospital] = useState(null); // Updated to selectedHospital

  useEffect(() => {
    dispatch(fetchHospitals());
  }, [dispatch]);

  const handleDeleteHospital = (id) => {
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',
    }).then((result) => {
      if (result.isConfirmed) {
        dispatch(deleteHospital(id)).then(() => {
          Swal.fire('Deleted!', 'The hospital has been deleted.', 'success');
          refreshHospitalList(); 
        });
      }
    });
  };

  const handleEditHospital = (hospital) => {
    setSelectedHospital(hospital);
    setIsEditing(true);
  };

  const handleAddHospital = () => {
    setIsAdding(true);
  };

  const handleFormClose = () => {
    setIsAdding(false);
    setIsEditing(false);
    setSelectedHospital(null);
  };

  const refreshHospitalList = () => {
    dispatch(fetchHospitals());
  };

  const columns = [
    { field: 'id', headerName: 'ID', flex: 0.5 },
    { field: 'name', headerName: 'Hospital Name', flex: 1 },
    { field: 'address', headerName: 'Address', flex: 1 },
    { field: 'city', headerName: 'City', flex: 1 },
    { field: 'state', headerName: 'State', flex: 1 },
    { field: 'zipCode', headerName: 'Zip Code', flex: 1 },
    { field: 'phone_number', headerName: 'Phone Number', flex: 1 },
    { field: 'email', headerName: 'Email', flex: 1 },
    {
      field: 'actions',
      headerName: 'Actions',
      flex: 1,
      renderCell: (params) => (
        <Box>
          {userPermissions?.HospitalLists?.can_update && (
            <IconButton onClick={() => handleEditHospital(params.row)}>
              <EditIcon style={{ color: colors.greenAccent[200] }} />
            </IconButton>
          )}
          {userPermissions?.HospitalLists?.can_delete && (
            <IconButton onClick={() => handleDeleteHospital(params.row.id)}>
              <DeleteIcon style={{ color: colors.redAccent[200] }} />
            </IconButton>
          )}
        </Box>
      ),
    },
  ];

  return (
    <Box m="20px">
      {(!isAdding && !isEditing) && userPermissions?.HospitalLists?.can_view && (
        <>
          <Header title="Hospital List" />
          <Box display="flex" justifyContent="flex-end" m="20px">
            {userPermissions?.HospitalLists?.can_create && (
              <Button
                variant="contained"
                color="primary"
                startIcon={<AddIcon />}
                onClick={handleAddHospital}
              >
                Add Hospital
              </Button>
            )}
          </Box>
          <Box
            m="40px 0 0 0"
            height="75vh"
            sx={{
              '& .MuiDataGrid-root': {
                border: 'none',
              },
              '& .MuiDataGrid-cell': {
                borderBottom: 'none',
              },
              '& .MuiDataGrid-columnHeaders': {
                backgroundColor: colors.blueAccent[700],
                borderBottom: 'none',
              },
              '& .MuiDataGrid-virtualScroller': {
                backgroundColor: colors.primary[400],
              },
              '& .MuiDataGrid-footerContainer': {
                borderTop: 'none',
                backgroundColor: colors.blueAccent[700],
              },
              '& .MuiCheckbox-root': {
                color: `${colors.greenAccent[200]} !important`,
              },
              '& .MuiDataGrid-toolbarContainer .MuiButton-text': {
                color: `${colors.grey[100]} !important`,
              },
            }}
          >
            <DataGrid
              rows={allHospitals}
              columns={columns}
              components={{ Toolbar: GridToolbar }}
            />
          </Box>
        </>
      )}
      {userPermissions?.HospitalLists?.can_create && isAdding && (
        <CreateHospital handleFormClose={handleFormClose} refreshHospitalList={refreshHospitalList} />
      )}
      {userPermissions?.HospitalLists?.can_update && isEditing && (
        <UpdateHospital handleFormClose={handleFormClose} selectedHospital={selectedHospital} refreshHospitalList={refreshHospitalList} />
      )}
    </Box>
  );
};

export default HospitalLists;
