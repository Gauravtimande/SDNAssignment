import React from "react";
import './Home.css';
const Home = () => {
  return (
    <div>
      <div>
        <section className="slider">
          <div className="hero-slider">
            <div
              className="single-slider"
              style={{ backgroundImage: 'url("assets/slider3.jpg")' }}
            >
              <div className="container">
                <div className="row">
                  <div className="col-lg-7">
                    <div className="text">
                      <h1>
                        Connecting <span> You </span> with Trusted
                        <span> Healthcare </span> Providers
                      </h1>
                      <p>
                        <span>
                          "Expert Care, Anytime, Anywhere" At Aspath Healthcare.
                        </span>
                      </p>
                      <p>
                        we connect you with a trusted network of healthcare
                        providers, offering a wide range of services from
                        diagnostics and pharmacy to emergency and home care. Our
                        platform ensures you receive quality care with
                        professionalism and compassion, wherever you are. Your
                        health is our priority, and with us, expert care is
                        always just a click away.
                      </p>
                      <div className="button">
                        <a href="/login" className="btn">
                          SignIn
                        </a>
                        <a href="/signup" className="btn primary">
                         SignUp
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* <!--/End Start schedule Area --> */}
    </div>
  );
};

export default Home;
