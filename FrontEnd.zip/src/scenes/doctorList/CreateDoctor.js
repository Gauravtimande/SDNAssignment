import React, { useState } from "react";
import { Box, Typography, TextField, Button, FormControl, InputLabel, Select, MenuItem } from "@mui/material";
import { useDispatch } from "react-redux";
import { createDoctor } from "../../context/Slice/doctorSlice"; // Ensure this action is appropriately defined for doctor registration
import styles from "./DoctorCreateForm.module.css";

const specialtyOptions = [
  "Cardiologist",
  "Dermatologist",
  "Neurologist",
  "Pediatrician",
  "Other",
];

export default function CreateDoctor({ handleFormClose, refreshDoctorList }) {
  const dispatch = useDispatch();

  const [formState, setFormState] = useState({
    specialty: specialtyOptions[0],
    firstName: "",
    lastName: "",
    licenseNumber: "",
    phone_number: "",
    email: "",
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSpecialtyChange = (event) => {
    setFormState((prevState) => ({
      ...prevState,
      specialty: event.target.value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const postData = { ...formState };
    console.log(postData);

    try {
      await dispatch(createDoctor(postData)); // Adjust the action as necessary for doctor registration
      refreshDoctorList();
      handleFormClose();
    } catch (error) {
      console.error("Registration error:", error);
      // Handle error (e.g., show an error message to the user)
    }
  };

  return (
    <div className={styles.container}>
      <Box component="form" className={styles.form} onSubmit={handleSubmit}>
        <Typography component="h1" variant="h5">Create Doctor</Typography>

        {/* Specialty Dropdown */}
        <FormControl fullWidth sx={{ marginBottom: "10px", marginTop: "20px" }}>
          <InputLabel>Specialty</InputLabel>
          <Select
            name="specialty"
            value={formState.specialty}
            onChange={handleSpecialtyChange}
            label="Specialty"
          >
            {specialtyOptions.map((option) => (
              <MenuItem key={option} value={option}>{option}</MenuItem>
            ))}
          </Select>
        </FormControl>

        {/* Name Fields */}
        <Box component="div" className={styles.nameContainer}>
          <TextField
            className={styles.nameInput}
            autoComplete="given-name"
            name="firstName"
            required
            fullWidth
            id="firstName"
            label="First Name"
            value={formState.firstName}
            autoFocus
            onChange={handleChange}
          />
          <TextField
            className={styles.nameInput}
            autoComplete="given-name"
            name="lastName"
            required
            fullWidth
            id="lastName"
            label="Last Name"
            value={formState.lastName}
            onChange={handleChange}
          />
        </Box>

        {/* License Number Field */}
        <TextField
          margin="normal"
          required
          fullWidth
          name="licenseNumber"
          id="licenseNumber"
          label="License Number"
          value={formState.licenseNumber}
          onChange={handleChange}
        />

        {/* Phone Number Field */}
        <TextField
          margin="normal"
          fullWidth
          name="phone_number"
          label="Phone Number"
          type="text"
          id="phone_number"
          value={formState.phone_number}
          onChange={handleChange}
        />

        {/* Email Field */}
        <TextField
          margin="normal"
          required
          fullWidth
          name="email"
          id="email"
          type="email"
          label="Email Address"
          value={formState.email}
          autoComplete="email"
          onChange={handleChange}
        />

        {/* Submit Button */}
        <Button type="submit" fullWidth variant="contained" sx={{ mt: 3, mb: 2 }}>
          Submit
        </Button>
        <Button fullWidth variant="contained" sx={{ mt: 2, mb: 2 }} onClick={handleFormClose}>
          Close
        </Button>

      </Box>
    </div>
  );
}
