import React, { useEffect, useState } from 'react';
import { Box, Button, IconButton } from '@mui/material';
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { tokens } from '../../theme';
import Header from '../../components/Header';
import { useTheme } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { fetchDoctors, deleteDoctor } from '../../context/Slice/doctorSlice';
import { usePermissions } from '../../context/PermissionsContext';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import Swal from 'sweetalert2';
import CreateDoctor from '../../scenes/doctorList/CreateDoctor';
import UpdateDoctor from '../../scenes/doctorList/UpdateDoctor';

const DoctorList = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const dispatch = useDispatch();
  const allDoctors = useSelector((state) => state.doctorR.doctors);
  const { userPermissions } = usePermissions();

  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState(null);

  useEffect(() => {
    dispatch(fetchDoctors());
  }, [dispatch]);

  const handleDeleteDoctor = (id) => {
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',
    }).then((result) => {
      if (result.isConfirmed) {
        dispatch(deleteDoctor(id))
          .then(() => {
            Swal.fire('Deleted!', 'The doctor has been deleted.', 'success');
            refreshDoctorList(); // Refresh the list after deletion
          })
          .catch((error) => {
            Swal.fire('Error!', 'There was a problem deleting the doctor.', 'error');
          });
      }
    });
  };
  

  const handleEditDoctor = (doctor) => {
    setSelectedDoctor(doctor);
    setIsEditing(true);
  };

  const handleAddDoctor = () => {
    setIsAdding(true);
  };

  const handleFormClose = () => {
    setIsAdding(false);
    setIsEditing(false);
    setSelectedDoctor(null);
  };

  const refreshDoctorList = () => {
    dispatch(fetchDoctors());
  };

  const columns = [
    { field: 'id', headerName: 'ID', flex: 0.5 },
    { field: 'firstName', headerName: 'First Name', flex: 1 },
    { field: 'lastName', headerName: 'Last Name', flex: 1 },
    { field: 'email', headerName: 'email', flex: 1 },
    { field: 'licenseNumber', headerName: 'License Number', flex: 1 },
    { field: 'phone_number', headerName: 'Phone Number', flex: 1 },
    { field: 'specialty', headerName: 'Specialty', flex: 1 },
    {
      field: 'actions',
      headerName: 'Actions',
      flex: 1,
      renderCell: (params) => (
        <Box>
          {userPermissions?.DoctorList?.can_update && (
            <IconButton onClick={() => handleEditDoctor(params.row)}>
              <EditIcon style={{ color: colors.greenAccent[200] }} />
            </IconButton>
          )}
          {userPermissions?.DoctorList?.can_delete && (
            <IconButton onClick={() => handleDeleteDoctor(params.row.id)}>
              <DeleteIcon style={{ color: colors.redAccent[200] }} />
            </IconButton>
          )}
        </Box>
      ),
    },
  ];

  return (
    <Box m="20px">
      {(!isAdding && !isEditing) && userPermissions?.DoctorList?.can_view && (
        <>
          <Header title="Doctors List" />
          <Box display="flex" justifyContent="flex-end" m="20px">
            {userPermissions?.DoctorList?.can_create && (
              <Button
                variant="contained"
                color="primary"
                startIcon={<AddIcon />}
                onClick={handleAddDoctor}
              >
                Add Doctor
              </Button>
            )}
          </Box>
          <Box
            m="40px 0 0 0"
            height="75vh"
            sx={{
              '& .MuiDataGrid-root': {
                border: 'none',
              },
              '& .MuiDataGrid-cell': {
                borderBottom: 'none',
              },
              '& .MuiDataGrid-columnHeaders': {
                backgroundColor: colors.blueAccent[700],
                borderBottom: 'none',
              },
              '& .MuiDataGrid-virtualScroller': {
                backgroundColor: colors.primary[400],
              },
              '& .MuiDataGrid-footerContainer': {
                borderTop: 'none',
                backgroundColor: colors.blueAccent[700],
              },
              '& .MuiCheckbox-root': {
                color: `${colors.greenAccent[200]} !important`,
              },
              '& .MuiDataGrid-toolbarContainer .MuiButton-text': {
                color: `${colors.grey[100]} !important`,
              },
            }}
          >
            <DataGrid
              rows={allDoctors}
              columns={columns}
              components={{ Toolbar: GridToolbar }}
            />
          </Box>
        </>
      )}
      {userPermissions?.DoctorList?.can_create && isAdding && (
        <CreateDoctor handleFormClose={handleFormClose} refreshDoctorList={refreshDoctorList} />
      )}
      {userPermissions?.DoctorList?.can_update && isEditing && (
        <UpdateDoctor handleFormClose={handleFormClose} selectedDoctor={selectedDoctor} refreshDoctorList={refreshDoctorList} />
      )}
    </Box>
  );
};

export default DoctorList;
