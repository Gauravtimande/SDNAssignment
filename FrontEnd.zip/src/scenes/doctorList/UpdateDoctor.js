import React, { useState, useEffect } from "react";
import { Box, Typography, TextField, Button, FormControl, InputLabel, Select, MenuItem } from "@mui/material";
import { useDispatch } from "react-redux";
import { updateDoctor } from "../../context/Slice/doctorSlice"; 
import styles from "./DoctorCreateForm.module.css"; 

const specialtyOptions = [
  "Cardiologist",
  "Dermatologist",
  "Neurologist",
  "Pediatrician",
  "Other",
];

export default function UpdateDoctor({ refreshDoctorList, handleFormClose, selectedDoctor }) {
  const dispatch = useDispatch();

  const [formState, setFormState] = useState({
    specialty: "",
    firstName: "",
    lastName: "",
    licenseNumber: "",
    phone_number: "",
    email: "",
  });

  useEffect(() => {
    if (selectedDoctor) {
      setFormState({
        specialty: selectedDoctor.specialty || "",
        firstName: selectedDoctor.firstName || "",
        lastName: selectedDoctor.lastName || "",
        licenseNumber: selectedDoctor.licenseNumber || "",
        phone_number: selectedDoctor.phone_number || "",
        email: selectedDoctor.email || "",
      });
    }
  }, [selectedDoctor]);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSpecialtyChange = (event) => {
    setFormState((prevState) => ({
      ...prevState,
      specialty: event.target.value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const updatedData = { id: selectedDoctor.id, formState };
    console.log(updatedData);

    try {
      await dispatch(updateDoctor(updatedData)); 
      refreshDoctorList();
      handleFormClose();
    } catch (error) {
      console.error("Update error:", error);
      
    }
  };

  return (
    <div className={styles.container}>
      <Box component="form" className={styles.form} onSubmit={handleSubmit}>
        <Typography component="h1" variant="h5">Update Doctor</Typography>

        <FormControl fullWidth sx={{ marginBottom: "10px", marginTop: "20px" }}>
          <InputLabel>Specialty</InputLabel>
          <Select
            name="specialty"
            value={formState.specialty}
            onChange={handleSpecialtyChange}
            label="Specialty"
          >
            {specialtyOptions.map((option) => (
              <MenuItem key={option} value={option}>{option}</MenuItem>
            ))}
          </Select>
        </FormControl>

       
        <Box component="div" className={styles.nameContainer}>
          <TextField
            className={styles.nameInput}
            autoComplete="given-name"
            name="firstName"
            required
            fullWidth
            id="firstName"
            label="First Name"
            value={formState.firstName}
            autoFocus
            onChange={handleChange}
          />
          <TextField
            className={styles.nameInput}
            autoComplete="given-name"
            name="lastName"
            required
            fullWidth
            id="lastName"
            label="Last Name"
            value={formState.lastName}
            onChange={handleChange}
          />
        </Box>

      
        <TextField
          margin="normal"
          required
          fullWidth
          name="licenseNumber"
          id="licenseNumber"
          label="License Number"
          value={formState.licenseNumber}
          onChange={handleChange}
        />

        
        <TextField
          margin="normal"
          fullWidth
          name="phone_number"
          label="Phone Number"
          type="text"
          id="phone_number"
          value={formState.phone_number}
          onChange={handleChange}
        />

     
        <TextField
          margin="normal"
          required
          fullWidth
          name="email"
          id="email"
          type="email"
          label="Email Address"
          value={formState.email}
          autoComplete="email"
          onChange={handleChange}
        />

 
        <Button type="submit" fullWidth variant="contained" sx={{ mt: 3, mb: 2 }}>
          Submit
        </Button>
        <Button fullWidth variant="contained" sx={{ mt: 2, mb: 2 }} onClick={handleFormClose}>
          Close
        </Button>
      </Box>
    </div>
  );
}
