import React, { useState } from "react";
import { Box, Typography, TextField, Button, FormControl, InputLabel, Select, MenuItem } from "@mui/material";

import styles from "./UserCreateForm.module.css";
import { useDispatch } from "react-redux";
import { userUpdate } from "../../context/Slice/loginSlice"; 

const roleOptions = [
  "SuperAdmin",
  "Providers",
  "Hospitals/Clinics",
  "Patient",
];

export default function UserUpdateForm({refreshUserList, handleFormClose,selectedUser }) {

  const dispatch = useDispatch();

  const [formState, setFormState] = useState({
    role: roleOptions[0],
    firstName: selectedUser.firstName || "",
    lastName: selectedUser.lastName || "",
    email:  selectedUser.email || "",
    password:  selectedUser.password || "",
    mobile_number:  selectedUser.mobile_number || "",
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleRoleChange = (event) => {
    setFormState((prevState) => ({
      ...prevState,
      role: event.target.value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    let id = selectedUser.id ;
    const postData = { id  ,formState };
    console.log(postData);
    dispatch(userUpdate(postData));
    refreshUserList();
    handleFormClose();
  };

  return (
    <div className={styles.container}>
      <Box component="form" className={styles.form} onSubmit={handleSubmit}>
        <Typography component="h1" variant="h">Update User</Typography>

        {/* Role Dropdown */}
        <FormControl fullWidth sx={{ marginBottom: "10px",marginTop:"20px" }}>
          <InputLabel>Role</InputLabel>
          <Select
            name="role"
            value={formState.role}
            onChange={handleRoleChange}
            label="Role"
          >
            {roleOptions.map((option) => (
              <MenuItem key={option} value={option}>{option}</MenuItem>
            ))}
          </Select>
        </FormControl>

        {/* Name Fields */}
        <Box component="div" className={styles.nameContainer}>
          <TextField
            className={styles.nameInput}
            autoComplete="given-name"
            name="firstName"
            required
            fullWidth
            id="firstName"
            label="First Name"
            value={formState.firstName}
            autoFocus
            onChange={handleChange}
          />
          <TextField
            className={styles.nameInput}
            autoComplete="given-name"
            name="lastName"
            required
            fullWidth
            id="lastName"
            label="Last Name"
            value={formState.lastName}
            onChange={handleChange}
          />
        </Box>

        {/* Email Field */}
        <TextField
          margin="normal"
          required
          fullWidth
          name="email"
          id="email"
          type="email"
          label="Email Address"
          value={formState.email}
          autoComplete="email"
          onChange={handleChange}
        />

        {/* Password Field */}
        <TextField
          margin="normal"
          required
          fullWidth
          name="password"
          label="Password"
          type="password"
          id="password"
          value={formState.password}
          onChange={handleChange}
        />

        {/* Mobile Number Field */}
        <TextField
          margin="normal"
          fullWidth
          name="mobile_number"
          label="Mobile Number"
          type="text"
          id="mobile_number"
          value={formState.mobile_number}
          onChange={handleChange}
        />

        {/* Submit Button */}
        <Button type="submit" fullWidth variant="contained" sx={{ mt: 3, mb: 2 }}>
            Submit
        </Button>
        <Button fullWidth variant="contained" sx={{ mt: 2, mb: 2 }} onClick={handleFormClose}>
          Close
        </Button>

      </Box>
    </div>
  );
}
