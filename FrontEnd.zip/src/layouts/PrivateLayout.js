import React from 'react';
import { Navigate } from 'react-router-dom';
import secureLocalStorage from 'react-secure-storage';
import Sidebar from '../scenes/global/Sidebar'; // Ensure correct path
import Topbar from '../scenes/global/Topbar';   // Ensure correct path
import './PrivateLayout.css'; // Ensure correct path

const PrivateLayout = ({ children }) => {
    const token = secureLocalStorage.getItem('token');

    if (!token) {
        return <Navigate to="/login" />;
    }

    return (
        <div className="app">
            <Sidebar />
            <div className="main-content">
                <Topbar />
                {children}
            </div>
        </div>
    );
};

export default PrivateLayout;
