import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import {jwtDecode} from 'jwt-decode'; // Import jwt-decode
import secureLocalStorage from 'react-secure-storage';


const PermissionsContext = createContext();

export const PermissionsProvider = ({ children }) => {

  const [userPermissions, setUserPermissions] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
   


  const getDefaultPermissions = (role) => {
    if (role === 'SuperAdmin') {
      return {
        role: 'SuperAdmin',
        Dashboard: { can_view: true },
        ManageTeam: { can_view: true },
        DoctorList: { can_view: true,can_create: true, can_update: true, can_delete: true },
        UserList: { can_view: true,can_create: true, can_update: true, can_delete: true },
        HospitalLists: { can_view: true,can_create: true, can_update: true, can_delete: true },
        ModulePermissions:{ can_view: true },
        ProfileForm: { can_view: true },
        BarChart: { can_view: true },
        Calendar: { can_view: true },
        GeographyChart: { can_view: true },
        LineChart: { can_view: true },
        PieChart: { can_view: true },
        FAQ: { can_view: true },
      };
    }
    return {};
  };

  useEffect(() => {
    const fetchPermissions = async () => {
      const token = secureLocalStorage.getItem('token');
      const user = JSON.parse(secureLocalStorage.getItem('user'));
  
      if (!token || !user || !user?.user?.role) {
        setLoading(false);
        setError('No valid user or token found');
        return;
      }
  
      try {
        if (user?.user?.role === 'SuperAdmin') {
          const defaultPermissions = getDefaultPermissions('SuperAdmin');
          setUserPermissions(defaultPermissions);
        } else {
          const decodedToken = jwtDecode(token);
          const userId = decodedToken?._id; // Ensure this is the correct field
  
          const response = await axios.get(`${process.env.REACT_APP_BASE_URL}/api/v1/permission/get-permisson/${userId}`, {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
  
          console.log("API response permissions:", response.data.data.permissions); // Add this log to verify API response
          setUserPermissions(response.data.data.permissions);

        }
      } catch (err) {
        console.error("Error fetching permissions:", err);
        setError(err.response?.data?.message || 'Error fetching permissions');
        if (err.response?.status === 401) {
          secureLocalStorage.removeItem('token');
          secureLocalStorage.removeItem('user');
        }
      } finally {
        setLoading(false);
      }
    };
  
    fetchPermissions();
  }, []);
  

  return (
    <PermissionsContext.Provider value={{ userPermissions, setUserPermissions, loading, error }}>
      {children}
    </PermissionsContext.Provider>
  );
};

export const usePermissions = () => useContext(PermissionsContext);
