import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import secureLocalStorage from "react-secure-storage";

const BASE_URL = process.env.REACT_APP_BASE_URL;


const getToken = () => {
  return secureLocalStorage.getItem("token");
};

// Async Thunks
export const createDoctor = createAsyncThunk(
  "doctor/createDoctor",
  async (doctorDetails, { rejectWithValue }) => {
    const token = getToken();
    try {
      const response = await axios.post(`${BASE_URL}/api/v1/Doctor/create-doctor`, doctorDetails, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
      );
      return response.data; 
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);

export const fetchDoctors = createAsyncThunk(
  "doctor/fetchDoctors",
  async (_, { rejectWithValue }) => {
    try {
      const token = getToken();
      const response = await axios.get(`${BASE_URL}/api/v1/Doctor/get-doctors`,{
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      return response.data.data; 
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);

export const fetchDoctorById = createAsyncThunk(
  "doctor/fetchDoctorById",
  async (id, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${BASE_URL}/api/v1/Doctor/get-doctor/${id}`);
      return response.data; 
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);

export const updateDoctor = createAsyncThunk(
  "doctor/updateDoctor",
  async (updatedData, { rejectWithValue }) => {
    try {
      const token = getToken();
      const response = await axios.put(`${BASE_URL}/api/v1/Doctor/update-doctor/${updatedData.id}`, updatedData.formState,{
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      return response.data; 
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);

export const deleteDoctor = createAsyncThunk(
  "doctor/deleteDoctor",
  async (id, { rejectWithValue }) => {
    try {
      const token = getToken();
      const response = await axios.delete(`${BASE_URL}/api/v1/Doctor/delete-doctor/${id}`,{
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      return response.data; 
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);

// Slice
const doctorSlice = createSlice({
  name: 'doctor',
  initialState: {
    doctors: [],
    currentDoctor: null,
    isLoading: false,
    error: null,
  },
  extraReducers: (builder) => {
    builder
      .addCase(createDoctor.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(createDoctor.fulfilled, (state, action) => {
        state.isLoading = false;
        state.doctors.push(action.payload.doctor);
      })
      .addCase(createDoctor.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })

      .addCase(fetchDoctors.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(fetchDoctors.fulfilled, (state, action) => {
        state.isLoading = false;
        state.doctors = action.payload;
      })
      .addCase(fetchDoctors.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })

      .addCase(fetchDoctorById.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(fetchDoctorById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.currentDoctor = action.payload.doctor;
      })
      .addCase(fetchDoctorById.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })

      .addCase(updateDoctor.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(updateDoctor.fulfilled, (state, action) => {
        state.isLoading = false;
        const index = state.doctors.findIndex(doctor => doctor.id === action.payload.doctor.id);
        if (index >= 0) {
          state.doctors[index] = action.payload.doctor;
        }
      })
      .addCase(updateDoctor.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })

      .addCase(deleteDoctor.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(deleteDoctor.fulfilled, (state, action) => {
        state.isLoading = false;
        state.doctors = state.doctors.filter(doctor => doctor.id !== action.payload.id);
      })
      .addCase(deleteDoctor.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      });
  },
});


export default doctorSlice.reducer;
