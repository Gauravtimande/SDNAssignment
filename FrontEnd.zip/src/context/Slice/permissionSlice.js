import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import secureLocalStorage from "react-secure-storage";

const BASE_URL = process.env.REACT_APP_BASE_URL;


const getToken = () => {
  return secureLocalStorage.getItem("token");
};


export const getPermissionsByUserId = createAsyncThunk(
  'permissions/getPermissionsByUserId',
  async (userId, { rejectWithValue }) => {
    try {
      const token = getToken();
      const response = await axios.get(`${BASE_URL}/api/v1/permission/get-permisson/${userId}`, {
        headers: {
          Authorization: `Bearer ${token}`
        },
      });
      return response.data.permissions; 
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);


export const createPermissionsByUserId = createAsyncThunk(
  'permissions/createPermissionsByUserId',
  async (data, { rejectWithValue }) => {
    try {
      const token = getToken();
      const response = await axios.post(`${BASE_URL}/api/v1/permission/add-permisson`, data, {
        headers: {
           Authorization: `Bearer ${token}`
        },
      });
      return response.data.permissions; 
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);

const permissionSlice = createSlice({
  name: 'permissions',
  initialState: {
    permissions: {},  
    isLoading: false,
    error: null,
  },

  extraReducers: (builder) => {
    builder
      .addCase(getPermissionsByUserId.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getPermissionsByUserId.fulfilled, (state, action) => {
        state.isLoading = false;
        state.permissions = action.payload; 
      })
      .addCase(getPermissionsByUserId.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload; 
      })
      .addCase(createPermissionsByUserId.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(createPermissionsByUserId.fulfilled, (state, action) => {
        state.isLoading = false;
        state.permissions = action.payload; 
      })
      .addCase(createPermissionsByUserId.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload; 
      });
  },
});

export default permissionSlice.reducer;
