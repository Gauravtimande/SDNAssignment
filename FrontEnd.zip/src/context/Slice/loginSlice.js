import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import secureLocalStorage from "react-secure-storage";

const BASE_URL = process.env.REACT_APP_BASE_URL;


const getToken = () => {
  return secureLocalStorage.getItem("token");
};

export const userLogin = createAsyncThunk(
  "auth/userLogin",
  async (credentials, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${BASE_URL}/api/v1/User/login`, credentials);
      const userData = response.data.data;

      const token = userData.access_token;
      if (token) {
        secureLocalStorage.setItem("token", token);
        secureLocalStorage.setItem("user", JSON.stringify(userData));
        return userData; 
      } else {
        return rejectWithValue("No access token found in the response");
      }
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);

export const userRegister = createAsyncThunk(
  "auth/userRegister",
  async (userDetails, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${BASE_URL}/api/v1/User/register-user`, userDetails);
      return response.data; 
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);

export const showAllUser = createAsyncThunk(
  "auth/showAllUser",
  async (_, { rejectWithValue }) => {
    try {
      const token = getToken();
      const response = await axios.get(`${BASE_URL}/api/v1/User/show-all-user`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      return response.data.data; 
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);

export const deleteUser = createAsyncThunk(
  "auth/deleteUser",
  async (id, { rejectWithValue }) => {
    try {
      const token = getToken();
      const response = await axios.delete(`${BASE_URL}/api/v1/User/delete-user/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);

export const userUpdate = createAsyncThunk(
  "auth/userUpdate",
  async (postData, { rejectWithValue }) => {
    try {
      const token = getToken();
      const response = await axios.put(`${BASE_URL}/api/v1/User/Update-user/${postData.id}`, postData.formState, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      return response.data; 
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);

const authSlice = createSlice({
  name: 'auth',
  initialState: {
    user: [],
    isLoading: false,
    error: null,
    role: null,
  },
  reducers: {
    openLoading: (state) => {
      state.isLoading = true;
    },
    closeLoading: (state) => {
      state.isLoading = false;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(userLogin.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(userLogin.fulfilled, (state, action) => {
        state.isLoading = false;
        state.user = action.payload;
        state.role = action.payload.user.role; 
      })
      .addCase(userRegister.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(userRegister.fulfilled, (state, action) => {
        state.isLoading = false;
        console.log("User registered:", action.payload);
      })
      .addCase(showAllUser.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(showAllUser.fulfilled, (state, action) => {
        state.isLoading = false;
        state.user = action.payload;
      })
      .addCase(deleteUser.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(deleteUser.fulfilled, (state, action) => {
        state.isLoading = false;
        state.user = action.payload;
      })
      .addCase(userUpdate.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(userUpdate.fulfilled, (state, action) => {
        state.isLoading = false;
        state.user = action.payload;
      })
      .addMatcher(
        (action) => action.type.endsWith('/rejected') && action.meta.rejectedWithValue,
        (state, action) => {
          state.isLoading = false;
          state.error = action.payload;
        }
      );
  },
});

export const { openLoading, closeLoading } = authSlice.actions;
export default authSlice.reducer;
