import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import secureLocalStorage from "react-secure-storage";
const BASE_URL = process.env.REACT_APP_BASE_URL;

const getToken = () => {
  return secureLocalStorage.getItem("token");
};

export const createHospital = createAsyncThunk(
  "hospital/createHospital",
  async (hospitalDetails, { rejectWithValue }) => {
    try {
      const token = getToken();
      const response = await axios.post(`${BASE_URL}/api/v1/hospital/create-hospital`, hospitalDetails,{
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      return response.data; 
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);

export const fetchHospitals = createAsyncThunk(
  "hospital/fetchHospitals",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${BASE_URL}/api/v1/hospital/get-hospitals`);
      return response.data.data; 
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);

export const fetchHospitalById = createAsyncThunk(
  "hospital/fetchHospitalById",
  async (id, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${BASE_URL}/api/v1/hospital/get-hospital/${id}`);
      return response.data; 
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);

export const updateHospital = createAsyncThunk(
  "hospital/updateHospital",
  async (updatedData, { rejectWithValue }) => {
    try {
      const token = getToken();
      const response = await axios.put(`${BASE_URL}/api/v1/hospital/update-hospital/${updatedData.id}`, updatedData.formState,{
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      return response.data; 
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);

export const deleteHospital = createAsyncThunk(
  "hospital/deleteHospital",
  async (id, { rejectWithValue }) => {
    try {
      const token = getToken();
      const response = await axios.delete(`${BASE_URL}/api/v1/hospital/delete-hospital/${id}`,{
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      return response.data; 
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || error.message);
    }
  }
);


const hospitalSlice = createSlice({
  name: 'hospital',
  initialState: {
    hospitals: [],
    currentHospital: null,
    isLoading: false,
    error: null,
  },
  reducers: {
    clearCurrentHospital: (state) => {
      state.currentHospital = null;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(createHospital.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(createHospital.fulfilled, (state, action) => {
        state.isLoading = false;
        state.hospitals.push(action.payload.hospital);
      })
      .addCase(createHospital.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })

      .addCase(fetchHospitals.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(fetchHospitals.fulfilled, (state, action) => {
        state.isLoading = false;
        state.hospitals = action.payload;
      })
      .addCase(fetchHospitals.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })

      .addCase(fetchHospitalById.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(fetchHospitalById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.currentHospital = action.payload.hospital;
      })
      .addCase(fetchHospitalById.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })

      .addCase(updateHospital.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(updateHospital.fulfilled, (state, action) => {
        state.isLoading = false;
        const index = state.hospitals.findIndex(hospital => hospital.id === action.payload.hospital.id);
        if (index >= 0) {
          state.hospitals[index] = action.payload.hospital;
        }
      })
      .addCase(updateHospital.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })

      .addCase(deleteHospital.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(deleteHospital.fulfilled, (state, action) => {
        state.isLoading = false;
        state.hospitals = state.hospitals.filter(hospital => hospital.id !== action.payload.id);
      })
      .addCase(deleteHospital.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      });
  },
});

export const { clearCurrentHospital } = hospitalSlice.actions;
export default hospitalSlice.reducer;
