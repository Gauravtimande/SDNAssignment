import { configureStore } from '@reduxjs/toolkit'
import loginReducer from './Slice/loginSlice'
import doctorReducer from './Slice/doctorSlice'
import hospitalReducer from './Slice/hospitalSlice'


export default configureStore({
  reducer: {
   
    loginR: loginReducer,
    doctorR: doctorReducer,
    hospitalR: hospitalReducer
    
  },
})