import React from "react";
import PrivateLayout from "../layouts/PrivateLayout";

import Dashboard from "../scenes/dashboard";
import Team from "../scenes/team";
import Invoices from "../scenes/invoices";
import UserList from "../scenes/userList";
import Bar from "../scenes/bar";
import UserCreateForm from "../scenes/form/UserCreateForm";
import Line from "../scenes/line";
import Pie from "../scenes/pie";
import FAQ from "../scenes/ModulePermissions/ModulePermissions";
import Calendar from "../scenes/calendar/calendar";
import Geography from "../scenes/geography";

import DoctorList from "../scenes/doctorList/DoctorList";
import ModulePermissions from "../scenes/ModulePermissions/ModulePermissions";
import HospitalLists from "../scenes/hospitalLists/HospitalLists";


const privateRoutes = [
  

  {
    path: "/dashboard",
    exact: true,
    element: <PrivateLayout><Dashboard /></PrivateLayout>
  },
  {
    path: "/team",
    exact: true,
    element: <PrivateLayout><Team /></PrivateLayout>
  },
  {
    path: "/userList",
    exact: true,
    element: <PrivateLayout><UserList /></PrivateLayout>
  },
  {
    path: "/DoctorList",
    exact: true,
    element: <PrivateLayout><DoctorList /></PrivateLayout>
  },
  {
    path: "/HospitalLists",
    exact: true,
    element: <PrivateLayout><HospitalLists /></PrivateLayout>
  },
  {
    path: "/invoices",
    exact: true,
    element: <PrivateLayout><Invoices /></PrivateLayout>
  },
  {
    path: "/userform",
    exact: true,
    element: <PrivateLayout><UserCreateForm /></PrivateLayout>
  },
  {
    path: "/bar",
    exact: true,
    element: <PrivateLayout><Bar /></PrivateLayout>
  },
  {
    path: "/pie",
    exact: true,
    element: <PrivateLayout><Pie /></PrivateLayout>
  },
  {
    path: "/line",
    exact: true,
    element: <PrivateLayout><Line /></PrivateLayout>
  },
  {
    path: "/faq",
    exact: true,
    element: <PrivateLayout><FAQ /></PrivateLayout>
  },
  {
    path: "/calendar",
    exact: true,
    element: <PrivateLayout><Calendar /></PrivateLayout>
  },
  {
    path: "/geography",
    exact: true,
    element: <PrivateLayout><Geography /></PrivateLayout>
  },
  {
    path: "/ModulePermissions",
    exact: true,
    element: <PrivateLayout><ModulePermissions /></PrivateLayout>
  },
 
];

export default privateRoutes;
