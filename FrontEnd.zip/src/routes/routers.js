import {createBrowserRouter}  from 'react-router-dom';
import publicRoutes from './publicRoutes.js';
import privateRoutes from './privateRoutes.js';

const routers = createBrowserRouter([
  ...publicRoutes,
  ...privateRoutes,
]);

export default routers;
