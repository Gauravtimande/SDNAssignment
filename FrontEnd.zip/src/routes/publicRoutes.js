import React from "react";
import PublicLayout from "../layouts/PublicLayout";
import SignIn from "../SignIn/SignIn";
import SignUp from "../SignUp/SignUp";
import  Home  from "../scenes/home/index";

const publicRoutes = [
    {
      path: "/",
      exact: true,
      element: <PublicLayout><Home /></PublicLayout>, 
    },
    {
      path: "/login",
      exact: true,
      element: <PublicLayout><SignIn /></PublicLayout>,
    },
    {
      path: "/signUp",
      exact: true,
      element: <PublicLayout><SignUp /></PublicLayout>,
    },
    // Add other public routes here if needed
  ];

export default publicRoutes;
