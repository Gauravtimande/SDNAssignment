import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import { Provider } from 'react-redux';
import Store from './context/Store';
import { PermissionsProvider } from './context/PermissionsContext';
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <PermissionsProvider>
    <Provider store={Store}>
      <App />
    </Provider>
  

    </PermissionsProvider>
  </React.StrictMode>
);
