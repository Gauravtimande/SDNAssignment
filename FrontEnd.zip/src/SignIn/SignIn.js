import React, { useState } from "react";
import { Box, Typography, TextField, Button } from "@mui/material";
import { Link,useNavigate } from "react-router-dom";
import styles from "./SignIn.module.css";
import { useDispatch } from "react-redux";
import { userLogin } from "../context/Slice/loginSlice"; 


export default function SignIn() {
  const navigate = useNavigate();
  const dispatch = useDispatch();


  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = async (event) => {
    event.preventDefault();

    const postData = { email, password };

   let response =  await dispatch(userLogin(postData))
    console.log("res",response)
    if (response.payload.status === "200") {
      navigate("/dashboard");
    }

    
  }
  return (
    <div className={styles.container}>
      <div className={styles.col1}>
        <Box
          component="form"
          className={styles.form}
          validate="true"
          onSubmit={handleSubmit}
        >
         
          <Typography component="h1" variant="h5">
            Sign in
          </Typography>

          {/* Email Field */}
          <TextField
            margin="normal"
            required
            fullWidth
            id="email"
            type="email"
            label="Email Address"
            name="email"
            value={email}
            autoComplete="email"
            autoFocus
            onChange={(event) => setEmail(event.target.value)}
          />

          {/* Password Field */}
          <TextField
            margin="normal"
            required
            fullWidth
            name="password"
            label="Password"
            type="password"
            id="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
          />

          {/* Submit Button */}
          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{ mt: 3, mb: 2 }}
          >
            Sign In
          </Button>

          <Link to="/signup" className={styles.linkBtn}>
            {"Don't have an account? Sign Up"}
          </Link>
        </Box>
      </div>
      <div className={styles.col2}>
        <img src="/medicine.svg" alt="doctor" draggable="false" />
      </div>
    </div>
  );
}
