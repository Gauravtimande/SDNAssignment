import jwt from "jsonwebtoken";
import { JWT_KEY } from "../const/credentials";
import { HTTP_MESSAGES } from "../const/message";
import response from "../const/response";

export const verifyJWT = (req, res, next) => {
  // Check if authorization header is present
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return response.somethingErrorMsgResponse(
      res,
      403,
      {},
      HTTP_MESSAGES.EN.TOKEN_INVALID
    );
  }

  
  const token = authHeader.split(" ")[1]; 

  if (!token) {
    return response.somethingErrorMsgResponse(
      res,
      403,
      {},
      HTTP_MESSAGES.EN.TOKEN_INVALID
    );
  }

  try {
    // Verify the token using the JWT_KEY
    const decoded = jwt.verify(token, JWT_KEY);
    req.user = decoded; // Attach decoded token (user) to request
    console.log("JWT validation done");
    return next();
  } catch (err) {
    console.log("JWT verification error", err);
    return response.unAuthorizedErrorMsgResponse(
      res,
      403,
      {},
      HTTP_MESSAGES.EN.TOKEN_EXPIRED
    );
  }
};
