const Joi = require('joi');

// User Validation Function
let userValidation = (req, res, next) => {
    let schema = Joi.object({
        firstName: Joi.string().min(3).max(50).required(),
        lastName: Joi.string().min(3).max(50).required(),
        email: Joi.string().email().required(),
        password: Joi.string().min(6).required(),
        mobile_number: Joi.string().pattern(/^[0-9]{10,15}$/).optional(),
        role: Joi.string().valid('SuperAdmin', 'Providers', 'Hospitals/Clinics', 'Patient').required(),
    });

    validateRequest(req, res, next, schema);
};



let hospitalValidation = (req, res, next) => {
    let schema = Joi.object({
        name: Joi.string().min(3).max(100).required(),
        address: Joi.string().min(10).max(200).required(),
        city: Joi.string().min(2).max(100).required(),
        state: Joi.string().min(2).max(100).required(),
        zipCode: Joi.string().pattern(/^[0-9]{5,10}$/).required(),
        phone_number: Joi.string().pattern(/^[0-9]{10,15}$/).optional(),
        email: Joi.string().email().optional(),
    });

    validateRequest(req, res, next, schema);
};


let doctorValidation = (req, res, next) => {
    let schema = Joi.object({
        firstName: Joi.string().min(3).max(50).required(),
        lastName: Joi.string().min(3).max(50).required(),
        specialty: Joi.string().min(3).max(100).required(),
        licenseNumber: Joi.string().min(6).max(50).required(),
        phone_number: Joi.string().pattern(/^[0-9]{10,15}$/).optional(),
        email: Joi.string().email().optional(),
    });

    validateRequest(req, res, next, schema);
};




const validateRequest = (req, res, next, schema) => {
    const { error } = schema.validate(req.body, { abortEarly: false });
    if (error) {
        return res.status(400).send({ result: 'validation fail', errors: error.details });
    }
    next();
};


module.exports = {
    userValidation,
    
    hospitalValidation,
    doctorValidation,
    
    validateRequest
};
