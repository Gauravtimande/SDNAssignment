import path from "path";
import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import { isDBConnected } from "./config/db.config";

import { userRouter } from "./routes/User-router";
import { hospitalRouter } from "./routes/Hospital-routes";
import { doctorRouter } from "./routes/Doctor-router";
import { permissionRouter } from "./routes/Permissions-router";


const app = express();
console.log('process.env.NODE_ENV--->',process.env.NODE_ENV)
// app.use(express.static('build'))

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
isDBConnected();

app.use("/api/v1/User",userRouter)
app.use("/api/v1/Doctor",doctorRouter)
app.use("/api/v1/hospital",hospitalRouter)
app.use("/api/v1/permission",permissionRouter)

  app.get("/", (req, res) => {
    res.send("API is running....");
  });


export default app;







