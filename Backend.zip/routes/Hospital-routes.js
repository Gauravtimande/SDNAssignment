import { verifyJWT } from '../middlewares/jwt';
import { hospitalValidation } from '../middlewares/validate';

const express = require('express');

const hospitalController = require('../controllers/hospital.controller');

export const hospitalRouter = express.Router();

hospitalRouter.post('/create-hospital',verifyJWT,hospitalValidation ,hospitalController.createHospital);
hospitalRouter.get('/get-hospitals',hospitalController.getHospitals);
hospitalRouter.get('/hospitals/:id', hospitalController.getHospitalById);
hospitalRouter.put('/update-hospital/:id',verifyJWT,hospitalValidation ,hospitalController.updateHospital);
hospitalRouter.delete('/delete-hospital/:id',verifyJWT ,hospitalController.deleteHospital);


