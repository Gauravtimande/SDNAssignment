import { JWT_KEY } from '../const/credentials';
import { verifyJWT } from '../middlewares/jwt';
import { permissionValidation } from '../middlewares/validate';

const express = require('express');
permissionValidation
const permissionController = require('../controllers/permission.controller');

export const permissionRouter = express.Router();

permissionRouter.post('/add-permisson', verifyJWT,permissionController.assignPermissions);

permissionRouter.get('/get-permisson/:id', verifyJWT,permissionController.getPermissionsByUserId);




