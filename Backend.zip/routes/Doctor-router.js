import { verifyJWT } from '../middlewares/jwt';

const express = require('express');
const doctorController = require('../controllers/doctor.controller');

export const doctorRouter = express.Router();

// Create a new doctor
doctorRouter.post('/create-doctor',verifyJWT ,doctorController.createDoctor);

// Get all doctors
doctorRouter.get('/get-doctors', verifyJWT,doctorController.getDoctors);

// Get a single doctor by ID
doctorRouter.get('/get-doctor/:id', doctorController.getDoctorById);

// Update a doctor by ID
doctorRouter.put('/update-doctor/:id', verifyJWT,doctorController.updateDoctor);

// Delete a doctor by ID
doctorRouter.delete('/delete-doctor/:id', doctorController.deleteDoctor);
