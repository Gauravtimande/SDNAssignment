import express from "express";
import { verifyJWT } from "../middlewares/jwt";
import { userValidation } from "../middlewares/validate";
const userControllers =  require( "../controllers/user.controller"); 

export const userRouter = express.Router();



userRouter.post("/login",userControllers.login );

userRouter.post("/register-user", userValidation,userControllers.register );


userRouter.get("/show-all-user",verifyJWT,userControllers.getAllUsers)

userRouter.delete("/delete-user/:id",verifyJWT,userControllers.deleteUser)

userRouter.put("/Update-user/:id",verifyJWT,userValidation,userControllers.updateUser)




