const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/db.config");

const Users = sequelize.define("Users", {
  id: {
    type: DataTypes.BIGINT,
    autoIncrement: true,
    primaryKey: true
  },
  firstName: {
    type: DataTypes.STRING,
    allowNull: false
  },
  lastName: {
    type: DataTypes.STRING,
    allowNull: false
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  },
  mobile_number: {
    type: DataTypes.STRING(15),
    allowNull: true
  },
  role: {
    type: DataTypes.ENUM('SuperAdmin', 'Providers', 'Hospitals/Clinics', 'Patient'),
    allowNull: false
  },
  deletedAt: {
    type: DataTypes.DATE,
    allowNull: true
  },
  createdAt: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: sequelize.literal('CURRENT_TIMESTAMP')
  },
  updatedAt: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: sequelize.literal('CURRENT_TIMESTAMP')
  }
}, {
  timestamps: true,
  tableName: 'Users'
});

// Associations
Users.associate = function (models) {
  Users.hasOne(models.Permissions, { foreignKey: 'userId' });
};

module.exports = Users;
