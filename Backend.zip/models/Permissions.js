const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/db.config");
const Users = require("./Users");

const Permissions = sequelize.define("Permissions", {
  id: {
    type: DataTypes.BIGINT,
    autoIncrement: true,
    primaryKey: true
  },
  userId: {  // Foreign Key to Users
    type: DataTypes.BIGINT,
    allowNull: false,
    references: {
      model: 'Users',
      key: 'id'
    }
  },
  permissions: {
    type: DataTypes.JSONB,
    defaultValue: [],
    allowNull: true
  },
  createdAt: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: sequelize.literal('CURRENT_TIMESTAMP')
  },
  updatedAt: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: sequelize.literal('CURRENT_TIMESTAMP')
  }
}, {
  timestamps: true,
  tableName: 'Permissions'
});

Permissions.belongsTo(Users, { foreignKey: 'userId', as: 'User' });

module.exports = Permissions;
