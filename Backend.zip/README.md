
    npx sequelize-cli --env development db:migrate
    ```
    ```


    NODE_ENV=local npx sequelize-cli db:seed --seed 001-create-admin.js
    ```
    ```npx sequelize-cli db:migrate --name 008-create-Event-table.js

