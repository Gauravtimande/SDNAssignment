// index.js
"use strict";
require("dotenv").config();
require("@babel/polyfill");
require("@babel/register");
const app = require("./app").default;
const path = require("path");
const http = require("http");




const env = process.env.NODE_ENV || "local";
const envData = require(path.join(__dirname, "./config", `${env}.config`));


let server;
const PORT = envData.config?.port || 5000;
server = http.createServer(app);
server.listen(PORT, () => {
    console.log(`Server running in ${process.env.NODE_ENV} mode on port ${PORT}`);
});
