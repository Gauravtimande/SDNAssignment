
import Doctor from "../models/Doctor";
import response from "../const/response";

// Create a new doctor
export const createDoctor = async (req, res) => {
  const { firstName, lastName, specialty, licenseNumber, phone_number, email } = req.body;
  console.log(req.body)

  try {
    // Check if doctor already exists
    const existingDoctor = await Doctor.findOne({ where: { licenseNumber } });
    if (existingDoctor) {
      return response.errorResponse(res, 400, {}, 'Doctor already exists');
    }

    // Create a new doctor
    const newDoctor = await Doctor.create({
      firstName,
      lastName,
      specialty,
      licenseNumber,
      phone_number,
      email
    });

    return response.successResponse(res, 201, {
      doctor: {
        id: newDoctor.id,
        firstName: newDoctor.firstName,
        lastName: newDoctor.lastName,
        specialty: newDoctor.specialty,
        licenseNumber: newDoctor.licenseNumber,
        phone_number: newDoctor.phone_number,
        email: newDoctor.email
      }
    }, 'Doctor created successfully');
  } catch (error) {
    console.error("Error during doctor creation:", error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};

// Get all doctors
export const getDoctors = async (req, res) => {
  try {
    const doctors = await Doctor.findAll();
    return response.successResponse(res, 200, doctors, 'Doctors retrieved successfully');
  } catch (error) {
    console.error('Error fetching doctors:', error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};

// Get a single doctor by ID
export const getDoctorById = async (req, res) => {
  const { id } = req.params;

  try {
    const doctor = await Doctor.findByPk(id);
    if (doctor) {
      return response.successResponse(res, 200, doctor, 'Doctor retrieved successfully');
    } else {
      return response.errorResponse(res, 404, {}, 'Doctor not found');
    }
  } catch (error) {
    console.error('Error fetching doctor:', error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};

// Update a doctor by ID
export const updateDoctor = async (req, res) => {
  const { id } = req.params;
  const { firstName, lastName, specialty, licenseNumber, phone_number, email } = req.body;

  try {
    const doctor = await Doctor.findByPk(id);
    if (!doctor) {
      return response.errorResponse(res, 404, {}, 'Doctor not found');
    }

    await doctor.update({
      firstName: firstName || doctor.firstName,
      lastName: lastName || doctor.lastName,
      specialty: specialty || doctor.specialty,
      licenseNumber: licenseNumber || doctor.licenseNumber,
      phone_number: phone_number || doctor.phone_number,
      email: email || doctor.email,
    });

    return response.successResponse(res, 200, doctor, 'Doctor updated successfully');
  } catch (error) {
    console.error('Error updating doctor:', error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};

// Delete a doctor by ID
export const deleteDoctor = async (req, res) => {
  const { id } = req.params;

  try {
    const doctor = await Doctor.findByPk(id);
    if (!doctor) {
      return response.errorResponse(res, 404, {}, 'Doctor not found');
    }

    await doctor.destroy();
    return response.successResponse(res, 200, {}, 'Doctor deleted successfully');
  } catch (error) {
    console.error('Error deleting doctor:', error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};
