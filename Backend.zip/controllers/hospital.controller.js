import Hospital from "../models/Hospital";
import response from "../const/response";

// Create a new hospital
export const createHospital = async (req, res) => {
  const { name, address, city, state, zipCode, phone_number, email } = req.body;

  try {
    // Create a new hospital
    const newHospital = await Hospital.create({
      name,
      address,
      city,
      state,
      zipCode,
      phone_number,
      email
    });

    return response.successResponse(res, 201, {
      hospital: {
        id: newHospital.id,
        name: newHospital.name,
        address: newHospital.address,
        city: newHospital.city,
        state: newHospital.state,
        zipCode: newHospital.zipCode,
        phone_number: newHospital.phone_number,
        email: newHospital.email
      }
    }, 'Hospital created successfully');
  } catch (error) {
    console.error("Error during hospital creation:", error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};

// Get all hospitals
export const getHospitals = async (req, res) => {
  try {
    const hospitals = await Hospital.findAll();
    return response.successResponse(res, 200, hospitals, 'Hospitals retrieved successfully');
  } catch (error) {
    console.error('Error fetching hospitals:', error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};

// Get a single hospital by ID
export const getHospitalById = async (req, res) => {
  const { id } = req.params;

  try {
    const hospital = await Hospital.findByPk(id);
    if (hospital) {
      return response.successResponse(res, 200, hospital, 'Hospital retrieved successfully');
    } else {
      return response.errorResponse(res, 404, {}, 'Hospital not found');
    }
  } catch (error) {
    console.error('Error fetching hospital:', error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};

// Update a hospital by ID
export const updateHospital = async (req, res) => {
  const { id } = req.params;
  const { name, address, city, state, zipCode, phone_number, email } = req.body;

  try {
    const hospital = await Hospital.findByPk(id);
    if (!hospital) {
      return response.errorResponse(res, 404, {}, 'Hospital not found');
    }

    await hospital.update({
      name: name || hospital.name,
      address: address || hospital.address,
      city: city || hospital.city,
      state: state || hospital.state,
      zipCode: zipCode || hospital.zipCode,
      phone_number: phone_number || hospital.phone_number,
      email: email || hospital.email,
    });

    return response.successResponse(res, 200, hospital, 'Hospital updated successfully');
  } catch (error) {
    console.error('Error updating hospital:', error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};

// Delete a hospital by ID
export const deleteHospital = async (req, res) => {
  const { id } = req.params;

  try {
    const hospital = await Hospital.findByPk(id);
    if (!hospital) {
      return response.errorResponse(res, 404, {}, 'Hospital not found');
    }

    await hospital.destroy();
    return response.successResponse(res, 200, {}, 'Hospital deleted successfully');
  } catch (error) {
    console.error('Error deleting hospital:', error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};
