import Permissions from "../models/Permissions";
import response from "../const/response";

// Assign permissions to a user
export const assignPermissions = async (req, res) => {
  const { userId, permissionsArray } = req.body;
  console.log("body",req.body)

  try {
    // Check if permissions already exist for the user
    const existingPermissions = await Permissions.findOne({ where: { userId } });
    if (existingPermissions) {
      return response.errorResponse(res, 400, {}, 'Permissions already assigned to this user');
    }

    // Create new permissions for the user
    await Permissions.create({
      userId,
      permissions: permissionsArray,
    });

    return response.successResponse(res, 201, {}, `Permissions assigned to user ${userId} successfully`);
  } catch (error) {
    console.error("Error assigning permissions:", error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};

// Get permissions by user ID
export const getPermissionsByUserId = async (req, res) => {
  const { id } = req.params;

  try {
    const userPermissions = await Permissions.findOne({ where: { userId: id } });

    if (!userPermissions) {
      return response.errorResponse(res, 404, {}, 'No permissions found for this user');
    }

    return response.successResponse(res, 200, userPermissions.permissions, 'Permissions retrieved successfully');
  } catch (error) {
    console.error("Error fetching permissions:", error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};

// Update permissions for a user
export const updatePermissions = async (req, res) => {
  const { userId } = req.params;
  const { permissionsArray } = req.body;

  try {
    const userPermissions = await Permissions.findOne({ where: { userId } });

    if (!userPermissions) {
      return response.errorResponse(res, 404, {}, 'Permissions not found for this user');
    }

    // Update permissions
    await userPermissions.update({
      permissions: permissionsArray,
    });

    return response.successResponse(res, 200, {}, `Permissions updated for user ${userId} successfully`);
  } catch (error) {
    console.error("Error updating permissions:", error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};

// Delete permissions for a user
export const deletePermissions = async (req, res) => {
  const { userId } = req.params;

  try {
    const userPermissions = await Permissions.findOne({ where: { userId } });

    if (!userPermissions) {
      return response.errorResponse(res, 404, {}, 'Permissions not found for this user');
    }

    // Delete the permissions
    await userPermissions.destroy();

    return response.successResponse(res, 200, {}, `Permissions deleted for user ${userId} successfully`);
  } catch (error) {
    console.error("Error deleting permissions:", error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};
