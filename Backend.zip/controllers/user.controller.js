import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { JWT_KEY } from "../const/credentials";
import Users from "../models/Users";
import response from "../const/response";

export const login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await Users.findOne({ where: { email } });

    if (!user) {
      return response.errorResponse(res, 404, {}, 'User not found');
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (isPasswordValid) {
      const role = user.role;
      const token = jwt.sign(
        { _id: user.id, email: user.email, role: role },
        JWT_KEY,
        { expiresIn: '24h' } 
      );

      return response.successResponse(res, 200, {
        status:"200",
        access_token: token,
        user: { id: user.id, email: user.email, role: role },
      }, 'Login successful');
    } else {
      return response.errorResponse(res, 401, {}, 'Incorrect password');
    }
  } catch (error) {
    console.error("Error during login:", error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};

export const register = async (req, res) => {
  const { firstName, lastName, email, password, mobile_number, role } = req.body;
          console.log("body",req.body)
  try {
   
    const existingUser = await Users.findOne({ where: { email } });
    if (existingUser) {
      return response.errorResponse(res, 400, {}, 'User already exists');
    }

   
    if (!password) {
      return response.errorResponse(res, 400, {}, 'Password is required');
    }

    // Hash the password (salt rounds = 10)
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user in the database
    const newUser = await Users.create({
      firstName,
      lastName,
      email,
      password: hashedPassword,
      mobile_number,
      role
    });

    console.log("New user created:", newUser);

    // Respond with success message and user details (excluding password)
    return response.successResponse(res, 201, {
      user: {
        id: newUser.id,
        email: newUser.email,
        role: newUser.role
      }
    }, 'User registered successfully');

  } catch (error) {
    // Log and return an error response
    console.error("Error during registration:", error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};


export const getAllUsers = async (req, res) => {
  try {
    const users = await Users.findAll({ attributes: { exclude: ['password'] } }); // Exclude password from response
    return response.successResponse(res, 200, users, 'Users retrieved successfully');
  } catch (error) {
    console.error('Error fetching users:', error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};


export const updateUser = async (req, res) => {
  const { id } = req.params;
  const { firstName, lastName, email, mobile_number, role } = req.body;
  console.log("id",id)
  console.log("req.body",req.body)

  try {
    const user = await Users.findByPk(id);

    if (!user) {
      return response.errorResponse(res, 404, {}, 'User not found');
    }

    // Update user details
    await user.update({
      firstName: firstName || user.firstName,
      lastName: lastName || user.lastName,
      email: email || user.email,
      mobile_number: mobile_number || user.mobile_number,
      role: role || user.role,
    });

    return response.successResponse(res, 200, user, 'User updated successfully');
  } catch (error) {
    console.error('Error updating user:', error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};



export const deleteUser = async (req, res) => {
  const { id } = req.params;

  try {
    const user = await Users.findByPk(id);

    if (!user) {
      return response.errorResponse(res, 404, {}, 'User not found');
    }

    // Soft delete user if using Sequelize with `paranoid` mode (with `deletedAt` field)
    await user.destroy();

    return response.successResponse(res, 200, {}, 'User deleted successfully');
  } catch (error) {
    console.error('Error deleting user:', error);
    return response.errorResponse(res, 500, {}, 'Internal server error');
  }
};
